# Black Owen — Prototype Repository

В этом репозитории собраны статические страницы сайта и пример контракта ERC‑20 для проекта **Black Owen**.

## Структура
- `index.html`, `about.html`, `wallet.html`, `token.html`, `dashboard.html` — статические страницы (ready for GitHub Pages)
- `assets/style.css` — стили
- `contracts/BlackOwenToken.sol` — пример ERC‑20 контракта (OpenZeppelin)
- `scripts/deploy.js` — скрипт деплоя (Hardhat)
- `hardhat.config.js`, `package.json` — конфигурация для разработки

## Быстрый старт (Static site)
1. Скопируй содержимое репозитория в новый GitHub репозиторий.
2. Включи GitHub Pages (Settings → Pages → branch: main, folder: / (root)).
3. Подожди несколько минут — сайт будет доступен по `https://<your-username>.github.io/<repo>/`

## Развёртывание контракта (Testnet → Mainnet)
1. Установи Node.js и npm.
2. `npm install`
3. Подготовь `.env` с переменными:
```
ALCHEMY_URL=your_alchemy_or_infura_http_url
DEPLOYER_PRIVATE_KEY=0x...
INITIAL_RECIPIENT=0x...  # адрес, который получит 3_000_000 BO
```
4. `npx hardhat run scripts/deploy.js --network polygonMumbai` (или другая сеть)
5. После деплоя скопируй адрес токена и вставь его в `wallet.html` в место `0xYOUR_DEPLOYED_TOKEN_ADDRESS`

## Важное про безопасность
- Никогда не храните приватные ключи в публичных местах.
- Тестируйте сначала в тестовой сети.
- Закажите аудит смарт-контрактов перед деплоем в mainnet.

## Что я могу сделать дальше
- Сгенерировать Git-репозиторий и загрузить его на GitHub (если разрешишь доступ или предоставишь ключ).
- Добавить CI (Actions) для автодеплоя на Pages.
- Улучшить Wallet: WalletConnect, транзакции ERC-20 approvals, history (via Alchemy/API), и AI-инструменты безопасности.

---
Если хочешь — скажи **"Создай ZIP и дай ссылку"** — и я подготовлю архив для скачивания.
