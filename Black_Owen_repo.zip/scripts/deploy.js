const hre = require("hardhat");
async function main(){
  const [deployer] = await hre.ethers.getSigners();
  console.log("Deploying from:", deployer.address);
  const recipient = process.env.INITIAL_RECIPIENT || "0xYOUR_RECIPIENT_ADDRESS";
  const Factory = await hre.ethers.getContractFactory("BlackOwenToken");
  const token = await Factory.deploy(recipient);
  await token.deployed();
  console.log("Token address:", token.address);
}
main().catch((error)=>{ console.error(error); process.exitCode=1; });
